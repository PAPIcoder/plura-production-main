import Unauthorized from '@/components/unauthorized'
import React from 'react'

type Props = {}

const Page = (props: Props) => {
  return <Unauthorized />
}

export default Page
